## Initial set up in R
require(dplyr)
require(tidyr)
rm(list=ls())
setwd("ENTER OWN DIRECTORY HERE WITH CSV FILES")

### RESPONSE VARIABLE

## Upload Our World In Data neonatal mortality rate dataset
owiddata<- read.csv("owid_neonatal_mortality_percentage_0_28_days.csv")
# extract most recent five years of data
owiddata <- subset(owiddata, owiddata$Year>2015)
# check five years for every country
table(table(owiddata$Code))
# extract average mortality rate from last five years
neonatal <- data.frame(neonatal_mortality=numeric(), Country=character())
for(i in unique(owiddata$Code)) {
  temp_file <- subset(owiddata, owiddata$Code==i)
  average <- mean(unique(temp_file$Mortality.rate..neonatal..per.1.000.live.births.))
  temp <- data.frame(Country=i, neonatal_mortality=average)
  neonatal <- rbind(neonatal, temp)
}
# clean data of regions rather than countries
neonatal <- neonatal[-c(51,192),]
# downloaded data has converted to proportion - convert back to per 1,000 births
neonatal <- mutate(neonatal, neonatal_mortality_rate=neonatal_mortality*10)
neonatal

### HOME ENVIRONMENT VARIABLES

## 1 Upload Our World In Data access to handwashing dataset
owiddata1 <- read.csv("owid_death_rate_per_100_000_no_access_handwashing.csv")
# extract most recent five years of data
owiddata1 <- subset(owiddata1, owiddata1$Year>2014)
# check five years for every country
table(table(owiddata1$Code))
# extract average lack of access to handwashing facilities from last five years
handwash <- data.frame(handwash_no_access=numeric(), Country=character())
for(i in unique(owiddata1$Code)) {
  temp_file <- subset(owiddata1, owiddata1$Code==i)
  average <- mean(unique(temp_file$Deaths...Cause..All.causes...Risk..No.access.to.handwashing.facility...Sex..Both...Age..All.Ages..Rate.))
  temp <- data.frame(Country=i, handwash_no_access=average)
  handwash <- rbind(handwash, temp)
}


## 2 Upload Our World In Data unsafe water access dataset
owiddata2 <- read.csv("owid_death_rate_per_100_000_unsafe_water.csv")
# extract most recent five years of data
owiddata2 <- subset(owiddata2, owiddata2$Year>2014)
# check five years for every country
table(table(owiddata2$Code))
# extract average unsafe water access from last five years
water <- data.frame(unsafe_water=numeric(), Country=character())
for(i in unique(owiddata2$Code)) {
  temp_file <- subset(owiddata2, owiddata2$Code==i)
  average <- mean(unique(temp_file$Deaths...Cause..All.causes...Risk..Unsafe.water.source...Sex..Both...Age..Age.standardized..Rate.))
  temp <- data.frame(Country=i, unsafe_water=average)
  water <- rbind(water, temp)
}


## 3 Upload Our World In Data poverty level dataset
owiddata3 <- read.csv("owid_poverty_explorer_share_below_usd2_15_day.csv")
# check data level by year
table(owiddata3$Year)
# extract 2018 data
owiddata3 <- subset(owiddata3, owiddata3$Year==2018)
# select just usd2.15 a day and country column
poverty <- dplyr::select(owiddata3, Share.below..2.15.a.day, Entity)
poverty <- dplyr::rename(poverty,  poverty_level = Share.below..2.15.a.day, Country = Entity )


## 4 Upload WHO poverty dataset
whodata <- read.csv("proportion_of_population_below_international_poverty_line_usd1_90_per_day.csv")
table(whodata$Period)
# extract 2015
whodata <- subset(whodata, whodata$Period==2015)
# select just value and country column and rename
poverty2 <- dplyr::select(whodata, Value, SpatialDimValueCode, ParentLocationCode)
poverty2 <- dplyr::rename(poverty2,  poverty_level = Value, Region = ParentLocationCode, Country = SpatialDimValueCode )


## 5 Upload Our World In Data undernourishment dataset
owiddata4 <- read.csv("owid_share_population_undernourished.csv")
# check data level by year
table(owiddata4$Year)
# extract average data 2017-2019
food <- data.frame(undernourished=numeric(), Country=character())
for(i in unique(owiddata4$Code)) {
  temp_file <- subset(owiddata4, owiddata4$Code==i)
  average <- mean(unique(temp_file$Prevalence.of.undernourishment....of.population.))
  temp <- data.frame(Country=i, undernourished=average)
  food <- rbind(food, temp)
}


## 6 Upload Our World In Data deaths per 100,000 due to unsafe sanitation dataset
owiddata5 <- read.csv("owid_death_rate_per_100_000_unsafe_sanitation.csv")
# extract most recent five years of data
owiddata5 <- subset(owiddata5, owiddata5$Year>2014)
# check five years for every country
table(table(owiddata5$Code))
# extract average unsafe water access from last five years
sanitation <- data.frame(sanitation=numeric(), Country=character())
for(i in unique(owiddata5$Code)) {
  temp_file <- subset(owiddata5, owiddata5$Code==i)
  average <- mean(unique(temp_file$Deaths...Cause..All.causes...Risk..Unsafe.sanitation...Sex..Both...Age..Age.standardized..Rate.))
  temp <- data.frame(Country=i, sanitation=average)
  sanitation <- rbind(sanitation, temp)
}


## 7 Upload Our World In Data deaths per 100,000 due to malnutrition dataset
owiddata6 <- read.csv("owid_deaths_per_100_000_from_malnutrition.csv")
# extract most recent five years of data
owiddata6 <- subset(owiddata6, owiddata6$Year>2014)
# check five years for every country
table(table(owiddata6$Code))
# extract average unsafe water access from last five years
malnutrition <- data.frame(malnutrition=numeric(), Country=character())
for(i in unique(owiddata6$Code)) {
  temp_file <- subset(owiddata6, owiddata6$Code==i)
  average <- mean(unique(temp_file$Deaths...Protein.energy.malnutrition...Sex..Both...Age..Age.standardized..Rate.))
  temp <- data.frame(Country=i, malnutrition=average)
  malnutrition <- rbind(malnutrition, temp)
}


## 8 Upload WHO breastfeeding dataset
whodata1 <- read.csv("infants_exclusively_breastfed_first_6mths_percent.csv")
# check data level by year
table(whodata1$Period)
# extract average data 2018
whodata1 <- subset(whodata1, whodata1$Period==2018)
# select just value and country column and rename
breastfeeding <- dplyr::select(whodata1, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
breastfeeding <- dplyr::rename(breastfeeding,  Region = ParentLocationCode, breastfeeding = FactValueNumeric, Country = SpatialDimValueCode )


## 9 Upload WHO low birth weight dataset
whodata2 <- read.csv("low_birth_weight_prevalence_percent.csv")
# check data level by year
table(whodata2$Period)
# extract average data 2015
whodata2 <- subset(whodata2, whodata2$Period==2015)
# select just value and country column and rename
low_birth_weight <- dplyr::select(whodata2, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
low_birth_weight <- dplyr::rename(low_birth_weight,  Region = ParentLocationCode, low_birth_weight = FactValueNumeric, Country = SpatialDimValueCode )


## 10 Upload WorldBank rural proportion dataset
wbdata <- read.csv("worldbank_proportion_population_rural.csv")
# select columns of country and 2005, delete first four empty rows and rename cols
rural <- dplyr::select(wbdata, World.Development.Indicators, X.47)
rural <- rural[-c(1,2,3,4),]
rural <- dplyr::rename(rural, Country = World.Development.Indicators, rural_prop = X.47)
# remove NAs
length(rural$rural_prop)
rural <- dplyr::filter(rural, !is.na(rural_prop))


## 11 Upload WHO minimum acceptable diet dataset
whodata3 <- read.csv("proportion_children_6_23_months_receive_acceptable_minimum_diet.csv")
# filter for most recent year's data
whodata3 <- dplyr::filter(whodata3, IsLatestYear=="true")
# select just value and country and region columns and rename
diet <- dplyr::select(whodata3, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
diet <- dplyr::rename(diet,  min_accept_diet = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


### HEALTH SERVICE VARIABLES

## 1 Upload WHO births attended by skilled health personnel dataset
whodata4 <- read.csv("births_attended_skilled_health_personnel.csv")
# filter for most recent year's data
whodata4 <- dplyr::filter(whodata4, IsLatestYear=="true")
# select just value and country and region columns and rename
births_attended <- dplyr::select(whodata4, FactValueNumeric, SpatialDimValueCode, Location, ParentLocationCode)
births_attended <- dplyr::rename(births_attended,  births_attended = FactValueNumeric, Country = SpatialDimValueCode, Name = Location, Region = ParentLocationCode )


## 2 Upload WHO nurses and midwives per 10,000 dataset
whodata5 <- read.csv("nurses_and_midwifery_personnel_per_10_000.csv")
# filter for most recent year's data
whodata5 <- dplyr::filter(whodata5, IsLatestYear=="true")
# select just value and country and region columns and rename
nurses_midwives <- dplyr::select(whodata5, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
nurses_midwives <- dplyr::rename(nurses_midwives,  nurses_midwives = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


## 3 Upload WorldBank healthcare spend dataset
wbdata1 <- read.csv("worldbank_healthcare_spend_percent_gdp.csv")
# select columns of country and 2005, delete first four empty rows and rename cols
healthcare_spend <- dplyr::select(wbdata1, World.Development.Indicators, X.47)
healthcare_spend <- healthcare_spend[-c(1,2,3,4),]
healthcare_spend <- dplyr::rename(healthcare_spend, Country = World.Development.Indicators, healthcare_spend = X.47)
# remove NAs 
length(healthcare_spend$healthcare_spend)
healthcare_spend <- dplyr::filter(healthcare_spend, !is.na(healthcare_spend))


## 4 Upload WHO proportion new mothers with healthcare check within two days of delivery dataset
whodata6 <- read.csv("health_check_within_two_days_delivery_percent.csv")
# filter for most recent year's data
whodata6 <- dplyr::filter(whodata6, IsLatestYear=="true")
# select just value and country and region columns and rename
post_delivery_check <- dplyr::select(whodata6, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
post_delivery_check <- dplyr::rename(post_delivery_check,  post_delivery_check = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


## 5 Upload WHO hospitals per 100,000 dataset
whodata7 <- read.csv("density_per_100_000_all_hospitals.csv")
# select just value and country and region columns and rename
all_hospitals_density <- dplyr::select(whodata7, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
all_hospitals_density <- dplyr::rename(all_hospitals_density,  all_hospitals_density = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


## 6 Upload WHO provincial hospitals per 100,000 dataset
whodata8 <- read.csv("density_per_100_000_provincial_hospitals.csv")
# filter for most recent year's data
whodata8 <- dplyr::filter(whodata8, IsLatestYear=="true")
# select just value and country and region columns and rename
prov_hospitals_density <- dplyr::select(whodata8, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
prov_hospitals_density <- dplyr::rename(prov_hospitals_density,  prov_hospitals_density = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


## 7 Upload WHO specialised hospitals per 100,000 dataset
whodata9 <- read.csv("density_per_100_000_specialised_hospitals.csv")
# filter for most recent year's data
whodata9 <- dplyr::filter(whodata9, IsLatestYear=="true")
# select just value and country and region columns and rename
spec_hospitals_density <- dplyr::select(whodata9, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
spec_hospitals_density <- dplyr::rename(spec_hospitals_density,  spec_hospitals_density = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


## 8 Upload WHO health centres per 100,000 dataset
whodata10 <- read.csv("density_per_100_000_health_centres.csv")
# filter for most recent year's data
whodata10 <- dplyr::filter(whodata10, IsLatestYear=="true")
# select just value and country and region columns and rename
hc_density <- dplyr::select(whodata10, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
hc_density <- dplyr::rename(hc_density,  hc_density = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


## 9 Upload WHO medical doctors per 10,000 dataset
whodata11 <- read.csv("medical_doctors_per_10000.csv")
# filter for most recent year's data
whodata11 <- dplyr::filter(whodata11, IsLatestYear=="true")
# select just value and country and region columns and rename
md_per_10_000 <- dplyr::select(whodata11, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
md_per_10_000 <- dplyr::rename(md_per_10_000,  md_per_10_000 = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


## 10 Upload WHO hospital beds per 10,000 dataset
whodata12 <- read.csv("hospital_beds_per_10_000.csv")
# filter for most recent year's data
whodata12 <- dplyr::filter(whodata12, IsLatestYear=="true")
# select just value and country and region columns and rename
beds_per_10_000 <- dplyr::select(whodata12, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
beds_per_10_000 <- dplyr::rename(beds_per_10_000,  beds_per_10_000 = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


## 11 Upload WHO proportion of neonates protected at birth with tetanus vaccine dataset
whodata13 <- read.csv("neonates_protected_at_birth_v_tetanus_percent.csv")
# filter for most recent year's data
whodata13 <- dplyr::filter(whodata13, IsLatestYear=="true")
# select just value and country and region columns and rename
tetanus <- dplyr::select(whodata13, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
tetanus <- dplyr::rename(tetanus,  tetanus = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


## 12 Upload WHO proportion of 1yr olds immunised for dtp vaccine dataset
whodata14 <- read.csv("dtp3_immunization_coverage_1yr_olds_percent.csv")
# filter for most recent year's data
whodata14 <- dplyr::filter(whodata14, IsLatestYear=="true")
# select just value and country and region columns and rename
dtp <- dplyr::select(whodata14, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
dtp <- dplyr::rename(dtp,  dtp = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


## 13 Upload WHO proportion of 1yr olds immunised for polio vaccine dataset
whodata15 <- read.csv("polio_immunisation_coverage_1yr_olds_percent.csv")
# filter for most recent year's data
whodata15 <- dplyr::filter(whodata15, IsLatestYear=="true")
# select just value and country and region columns and rename
polio <- dplyr::select(whodata15, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
polio <- dplyr::rename(polio,  polio = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


## 14 Upload WHO proportion of 1yr olds immunised with hib3 vaccine dataset
whodata16 <- read.csv("hib3_immunisation_coverage_1yr_olds_percent.csv")
# filter for most recent year's data
whodata16 <- dplyr::filter(whodata16, IsLatestYear=="true")
# select just value and country and region columns and rename
hib3 <- dplyr::select(whodata16, FactValueNumeric, SpatialDimValueCode, ParentLocationCode)
hib3 <- dplyr::rename(hib3,  hib3 = FactValueNumeric, Country = SpatialDimValueCode, Region = ParentLocationCode )


### MERGING THE DATASETS

# Response variable and births attended by skilled personnel
neo_data <- merge(neonatal, births_attended, "Country", "Country", all.x=TRUE)
# Add nurses-midwives
neo_data <- merge(neo_data, nurses_midwives, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region.y)
# Add healthcare spend
neo_data <- merge(neo_data, healthcare_spend, "Country", "Country", all.x=TRUE)
# Add healthcare check at two days
neo_data <- merge(neo_data, post_delivery_check, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add hospitals per 100,000
neo_data <- merge(neo_data, all_hospitals_density, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add provincial hospitals per 100,000
neo_data <- merge(neo_data, prov_hospitals_density, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add specialised hospitals per 100,000
neo_data <- merge(neo_data, spec_hospitals_density, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add health centres per 100,000
neo_data <- merge(neo_data, hc_density, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add medical doctors per 10,000
neo_data <- merge(neo_data, md_per_10_000, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add hospital beds per 10,000
neo_data <- merge(neo_data, beds_per_10_000, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add tetanus vaccine at birth
neo_data <- merge(neo_data, tetanus, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add dtp vaccine at 1yr
neo_data <- merge(neo_data, dtp, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add polio vaccine at 1yr
neo_data <- merge(neo_data, polio, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add hib3 vaccine at 1yr
neo_data <- merge(neo_data, hib3, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add handwashing
neo_data <- merge(neo_data, handwash, "Country", "Country", all.x=TRUE)
# Add water access
neo_data <- merge(neo_data, water, "Country", "Country", all.x=TRUE)
# Add poverty measure 1
neo_data <- merge(neo_data, poverty, by.x="Name", by.y="Country", all.x=TRUE)
# Add poverty measure 2
neo_data <- merge(neo_data, poverty2, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add undernourishment data
neo_data <- merge(neo_data, food, "Country", "Country", all.x=TRUE)
# Add deaths due to unsafe sanitation
neo_data <- merge(neo_data, sanitation, "Country", "Country", all.x=TRUE)
# Add deaths due to malnutrition
neo_data <- merge(neo_data, malnutrition, "Country", "Country", all.x=TRUE)
# Add breastfeeding rate
neo_data <- merge(neo_data, breastfeeding, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add low birth rate prevalence
neo_data <- merge(neo_data, low_birth_weight, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Add rural proportion of population
neo_data <- merge(neo_data, rural, "Country", "Country", all.x=TRUE)
# Add minimum acceptable diet
neo_data <- merge(neo_data, diet, "Country", "Country", all.x=TRUE)
neo_data <- dplyr::select(neo_data, -Region)
# Rename and move regional columns to start
neo_data <- dplyr::rename(neo_data,  Region = Region.x, CountryCode = Country, Country = Name)
neo_data <- dplyr::relocate(neo_data, Region, .before = CountryCode)


## CREATE BEST SET OF COMPLETE OBSERVATIONS

# Save initial file
write.csv(neo_data, "incomplete_obs.csv")
# remove duplicates
dups <- duplicated(neo_data[, c('CountryCode', 'neonatal_mortality')]) 
sum(dups)
neo_data <- neo_data[!dups,]
dups2 <- duplicated(neo_data[, c('CountryCode', 'neonatal_mortality')]) 
sum(dups2)

### JUST AFRICAN AND EASTERN-MEDITERREAN COUNTRIES
neo_data <- subset(neo_data, Region=="AFR" | Region=="EMR")

# check no of NAs per country
country_na <- data.frame(Count_na=numeric(), Country=character())
for(i in unique(neo_data$CountryCode)) {
  temp_file <- subset(neo_data, neo_data$CountryCode==i)
  sum_na <- sum(is.na(temp_file))
  temp <- data.frame(Country=i, count_na=sum_na)
  country_na <- rbind(country_na, temp)
}
country_na

# check no of NAs per variable
variable_na <- data.frame(Count_na=numeric(), Variable=character())
for(i in 1:ncol(neo_data)) {
  temp_file <- subset(neo_data, neo_data$ncol==i)
  sum_na <- sum(is.na(neo_data[[i]]))
  temp <- data.frame(Variable=i, count_na=sum_na)
  variable_na <- rbind(variable_na, temp)
}
variable_na

# remove highest NA variables; rerun variable and country NA checks
neo_data <- dplyr::select(neo_data, -poverty_level.x, -poverty_level.y, -breastfeeding, -min_accept_diet, 
                   -low_birth_weight, -prov_hospitals_density, -hc_density, -post_delivery_check, 
                   -spec_hospitals_density, -all_hospitals_density,
                   -undernourished, -tetanus)
# remove highest country NAs
neo_data <- dplyr::filter(neo_data, CountryCode!="PSE", CountryCode!="SSD", CountryCode!="SOM", CountryCode!="ZWE")


# save file
write.csv(neo_data, "complete_obs.csv")
# 65 obs with 18 cols
table(neo_data$Region)
str(neo_data)
neo_data$Region <- as.factor(neo_data$Region)


## INVESTIGATING RELATIONSHIPS AND COLLINEARITY
# investigate the response variable
graphics.off()
hist(neo_data$neonatal_mortality_rate)
max(neo_data$neonatal_mortality_rate)
min(neo_data$neonatal_mortality_rate)
mean(neo_data$neonatal_mortality_rate)
sd(neo_data$neonatal_mortality_rate)


## Investigate collinearity
# Question - Does the home environment or the healthcare service have the greater effect on
# neonatal mortality rates in African and ME countries?
# Response variable - Neonatal deaths
# Possible grouping - region
# Continuous explanatory variables - all other variables

require(psych)
pairs.panels(neo_data[,-c(1,2,3,4,5)])
# Can see that different vaccinations are highly correlated with one another
# as are sanitation, unsafe water and access to handwash facilities

## calculate variance inflation factors and reduce iteratively

require(car)
model_vif <- lm(neonatal_mortality_rate ~ births_attended + nurses_midwives + healthcare_spend + md_per_10_000 + beds_per_10_000 + dtp  + polio + hib3 + handwash_no_access + unsafe_water + sanitation + malnutrition + rural_prop, data=neo_data)
car::vif(model_vif)
# remove dtp
model_vif1 <- lm(neonatal_mortality_rate ~ births_attended + nurses_midwives + healthcare_spend + md_per_10_000 + beds_per_10_000 + polio + hib3 + handwash_no_access + unsafe_water + sanitation + malnutrition + rural_prop, data=neo_data)
car::vif(model_vif1)
# remove sanitation
model_vif2 <- lm(neonatal_mortality_rate ~ births_attended + nurses_midwives + healthcare_spend + md_per_10_000 + beds_per_10_000 + polio + hib3 + handwash_no_access + unsafe_water + malnutrition + rural_prop, data=neo_data)
car::vif(model_vif2)
# remove unsafe water
model_vif3 <- lm(neonatal_mortality_rate ~ births_attended + nurses_midwives + healthcare_spend + md_per_10_000 + beds_per_10_000 + polio + hib3 + handwash_no_access + malnutrition + rural_prop, data=neo_data)
car::vif(model_vif3)
# remove hib3 
model_vif4 <- lm(neonatal_mortality_rate ~ births_attended + nurses_midwives + healthcare_spend + md_per_10_000 + beds_per_10_000 + polio + handwash_no_access + malnutrition + rural_prop, data=neo_data)
car::vif(model_vif4)
# remove proportion of births attended by skilled personnel
model_vif5 <- lm(neonatal_mortality_rate ~ nurses_midwives + healthcare_spend + md_per_10_000 + beds_per_10_000 + polio + handwash_no_access + malnutrition + rural_prop, data=neo_data)
car::vif(model_vif5)
# remove medical doctors per 10,000
model_vif6 <- lm(neonatal_mortality_rate ~ nurses_midwives + healthcare_spend + beds_per_10_000 + polio + handwash_no_access + malnutrition + rural_prop, data=neo_data)
car::vif(model_vif6)
# all VIF now sub 3

## Create table of maximal model variables
require(huxtable)

Vars <- hux(
  Variable = c("Nurses and Midwives per ten thousand", "Healthcare spend as % of GDP", "Hospital beds per ten thousand", "Proportion of one year olds vaccinated against Polio", "Deaths per hundred thousand due to malnutrition", "Proportion of population living in rural area", "Deaths per hundred thousand due to no access to handwashing facilities"),
  Category = c("Healthcare Service", "Healthcare Service", "Healthcare Service", "Healthcare Service", "Home Environment", "Home Environment", "Home Environment"),
  "Data Repository" = c("World Health Organisation", "World Bank Data", "World Health Organisation", "World Health Organisation", "Our World in Data", "World Bank Data", "Our World in Data"),
  add_colnames = TRUE
)

bold(Vars)[1,]           <- TRUE
bottom_border(Vars)[1,]  <- 0.4
right_padding(Vars)      <- 10
left_padding(Vars)       <- 10
width(Vars)              <- 0.5
number_format(Vars)      <- 3

Vars


## FITTING A LM MODEL

lm1 <- lm(neonatal_mortality_rate ~ scale(nurses_midwives) + scale(healthcare_spend) + scale(beds_per_10_000) + 
            scale(polio) + scale(handwash_no_access) + scale(malnutrition) +
            scale(rural_prop), data=neo_data)
summary(lm1)
# R2 0.62, F 15.9

# reduce model removing malnutrition (p=0.93, error 10x size of effect)
lm2 <- lm(neonatal_mortality_rate ~ scale(nurses_midwives) + scale(healthcare_spend) + scale(beds_per_10_000) + 
            scale(polio) + scale(handwash_no_access)  +
            scale(rural_prop), data=neo_data)
summary(lm2)
# R2 0.63, F 18.9
anova(lm1, lm2)
# variance of residuals has barely changed, F 0.14 nd p value 0.87 - can simplify without losing explanatory power

# reduce model removing healthcare spend (p=0.68, error size >2x effect size)
lm3 <- lm(neonatal_mortality_rate ~ scale(nurses_midwives) + scale(beds_per_10_000) + 
            scale(polio) + scale(handwash_no_access)  +
            scale(rural_prop), data=neo_data)
summary(lm3)
# R2 0.63, F 23
anova(lm3, lm2)
# variance of residuals has barely changed - F 0.17 nd p value 0.68 - can simplify without losing explanatory power

# reduce model removing density of nurses and midwives (p=0.64, error 2x effect size)
lm4 <- lm(neonatal_mortality_rate ~  scale(beds_per_10_000) + 
            scale(polio) + scale(handwash_no_access)  +
            scale(rural_prop), data=neo_data)
summary(lm4)
# R2 0.64, F 29
anova(lm3, lm4)
#  variance of residuals has barely changed - F 0.23 nd p value 0.64 - can simplify without losing explanatory power
# lm4 is the minimum adequate model


### DIAGNOSTICS
par(mfrow=c(2,2))
plot(lm4)
# no outliers (all within 0.5 Cook's distance), normal q-q plot looks linear
# residuals vs fitted look ok - slightly more variance for mid-fitted-values than the extremes
# no assumptions violated

# Plot relationships figure
require(ggplot2)
hwlm <- ggplot(neo_data, aes(x=scale(handwash_no_access), y=neonatal_mortality_rate))+
  geom_point()+
  labs(x= "Scaled Deaths per 100,000 due to lack of handwashing facilities", y="Neonatal Mortality rate")+
  geom_abline(intercept=21.67, slope=2.42) + annotate("text", x = 2, y = 15, label = "Slope = 2.42")
theme_classic()
rplm <- ggplot(neo_data, aes(x=scale(rural_prop), y=neonatal_mortality_rate))+
  geom_point() + annotate("text", x = -1.5, y = 40, label = "Slope = 3.63") +
  labs(x= "Scaled Proportion of population living in rural locations (%)", y="Neonatal Mortality rate")+
  geom_abline(intercept=21.67, slope=3.637)
theme_classic()
bedlm <- ggplot(neo_data, aes(x=scale(beds_per_10_000), y=neonatal_mortality_rate))+
  geom_point() + annotate("text", x = 1.5, y = 40, label = "Slope = -2.54")+
  labs(x= "Scaled Hospital beds per 100,000 people", y="Neonatal Mortality rate")+
  geom_abline(intercept=21.67, slope=-2.540)
theme_classic()
pollm <- ggplot(neo_data, aes(x=scale(polio), y=neonatal_mortality_rate))+
  geom_point() + annotate("text", x = -2, y = 15, label = "Slope = -3.16")+
  labs(x= "Scaled Proportion of 1yr olds vaccinated against polio (%)", y="Neonatal Mortality rate")+
  geom_abline(intercept=21.67, slope=-3.158)
theme_classic()

require(ggpubr)

figure <- ggarrange(hwlm, rplm, bedlm, pollm,
                    labels = c("A", "B", "C", "D"),
                    ncol = 2, nrow = 2)
figure

figure2 <- ggarrange(rplm, pollm,
                    labels = c("A", "B"),
                    ncol = 1, nrow = 2)
figure2

## Create table of parameter estimates
Sys.setlocale("LC_ALL","en_US.UTF-8")
paste0("a", 2, "±", 3, "b", collapse = "")

parlm <- hux(
  Coefficient = c("Intercept", "Sc. Hospital beds per hundred thousand", "Sc. Proportion vaccinated against polio", "Sc. Deaths from no handwashing facilities", "Sc. Proportion living in rural areas"),
  "Estimate SE" = c(paste0("21.672", "±", "0.812", collapse = ""), paste0("-2.539", "±", "1.009", collapse = ""), paste0("-3.158", "±", "0.920", collapse = ""), paste0("2.424", "±", "1.192", collapse = ""), paste0("3.637", "±", "1.077", collapse = "")),
  "t value" = c("26.698", "-2.517", "-3.433", "2.033", "3.376"),
  "p value" = c("<0.001", "0.015", "0.001", "0.046", "0.001"),
  add_colnames = TRUE
)

bold(parlm)[1,]           <- TRUE
bottom_border(parlm)[1,]  <- 0.4
align(parlm)[,2:4]          <- "right"
right_padding(parlm)      <- 10
left_padding(parlm)       <- 10
width(parlm)              <- 0.4
number_format(parlm)      <- 3

parlm

### INVESTIGATING THE MIN AD MODEL VARIABLES
par(mfrow=c(2,2))
hist(neo_data$handwash_no_access)
max(neo_data$handwash_no_access)
min(neo_data$handwash_no_access)
mean(neo_data$handwash_no_access)
sd(neo_data$handwash_no_access)

hist(neo_data$rural_prop)
max(neo_data$rural_prop)
min(neo_data$rural_prop)
mean(neo_data$rural_prop)
sd(neo_data$rural_prop)

hist(neo_data$polio)
max(neo_data$polio)
min(neo_data$polio)
mean(neo_data$polio)
sd(neo_data$polio)

hist(neo_data$beds_per_10_000)
max(neo_data$beds_per_10_000)
min(neo_data$beds_per_10_000)
mean(neo_data$beds_per_10_000)
sd(neo_data$beds_per_10_000)
